<?php

if (file_exists(__DIR__.'/../var/cache/dev/App_KernelDevDebugContainer.preload.php')) {
    require __DIR__.'/../var/cache/dev/App_KernelDevDebugContainer.preload.php';
}
