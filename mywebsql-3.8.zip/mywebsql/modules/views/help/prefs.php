	<div class="heading">Preferences</div>
		<ul>
			<li>Since MyWebSQL is a web based application, it stores its preferences in the form of cookies on your system.</li>
			<li>If you cleanup your browser cookies, the preferences will be lost.</li>
			<li>The default application preferences ensure maximum performance. You can, however change them anytime to suit your needs, using the menu inside the application.</li>
		</ul>
	</div>

