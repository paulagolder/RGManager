	<div class="heading">Credits</div>
		<div>Following softwares/people were extremely helpful during the development of MyWebSQL.</div>
		<ul>
			<li>jQuery<br>Starting with version 1.0, the whole interface for MyWebSQL is designed using jQuery, one of the finest Javascript library in the world.</li>
			<li>jQuery UI<br>An extremely useful GUI and widget library for jQuery.</li>
			<li>Plugins<br>Many useful jQuery plugins are used for client side functionality in MyWebSQL. Please see individual references in the script files provided with the source code.</li>
			<li>CodeMirror<br>Finest javascript code editor on the web. Great support from the developers makes it ideal for use in MyWebSQL. Minor modifications were done to make it work for sql editing inside MyWebSQL.</li>
			<li>phpMyAdmin<br>Some part of mysql batch import code from the software is incorporated into Mywebsql.</li>
		</ul>
		<ul>
			<li>Project website is hosted on server provided by Ovais Tariq</li>
			<li>Google translation for the application language files is scripted by Zeeshan Khan</li>
			<li>Mysql 4 database support was added to the software by Ally Shayan.</li>
			<li>Most of the icons/graphics are based on famfam icons and xiao icons.</li>
		</ul>
	</div>
