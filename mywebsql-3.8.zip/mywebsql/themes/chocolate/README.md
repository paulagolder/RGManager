MyWebSQL-Theme-chocolate
========================

Based on jQuery UI Mint chocolate theme